package com.alqude.edu.ArchiveSystem.entity;

public enum SemesterType {
    FIRST,   // Fall semester
    SECOND,  // Spring semester
    SUMMER   // Summer semester
}
