package com.alqude.edu.ArchiveSystem.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperConfig {
    // MapStruct mappers with @Mapper(componentModel = "spring") are automatically registered as Spring beans
    // No manual bean configuration needed
}
