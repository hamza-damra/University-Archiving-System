package com.alqude.edu.ArchiveSystem.dto.fileexplorer;

public enum NodeType {
    YEAR,
    SEMESTER,
    PROFESSOR,
    COURSE,
    DOCUMENT_TYPE,
    FILE
}
