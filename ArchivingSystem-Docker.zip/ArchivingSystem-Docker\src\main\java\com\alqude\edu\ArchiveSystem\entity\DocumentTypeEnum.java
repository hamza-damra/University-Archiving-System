package com.alqude.edu.ArchiveSystem.entity;

public enum DocumentTypeEnum {
    SYLLABUS,
    EXAM,
    ASSIGNMENT,
    PROJECT_DOCS,
    LECTURE_NOTES,
    OTHER
}
