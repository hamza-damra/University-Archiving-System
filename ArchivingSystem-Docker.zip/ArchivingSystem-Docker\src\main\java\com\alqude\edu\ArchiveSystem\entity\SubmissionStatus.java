package com.alqude.edu.ArchiveSystem.entity;

public enum SubmissionStatus {
    NOT_UPLOADED,
    UPLOADED,
    OVERDUE
}
